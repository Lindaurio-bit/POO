from abc import ABC, abstractmethod
from datetime import datetime

class Canal(ABC):
    @abstractmethod
    def enviar_mensagem(self, destinatario, mensagem):
        pass

class TelefoneCanal(Canal):
    def enviar_mensagem(self, numero, mensagem):
        print(f"Enviando mensagem para {numero}: {mensagem}")

class UsuarioCanal(Canal):
    def enviar_mensagem(self, usuario, mensagem):
        print(f"Enviando mensagem para {usuario}: {mensagem}")

class Mensagem(ABC):
    def __init__(self, conteudo):
        self.conteudo = conteudo
        self.data_envio = datetime.now()

class Texto(Mensagem):
    pass

class Video(Mensagem):
    def __init__(self, conteudo, duracao):
        super().__init__(conteudo)
        self.duracao = duracao

class Foto(Mensagem):
    pass

whatsapp = TelefoneCanal()
telegram = TelefoneCanal()
facebook = UsuarioCanal()

mensagem_texto = Texto("Olá, como você está?")
mensagem_video = Video("Vídeo legal", "2 minutos")

whatsapp.enviar_mensagem("+123456789", mensagem_texto)
telegram.enviar_mensagem("+987654321", mensagem_video)
facebook.enviar_mensagem("usuario_facebook", mensagem_texto)
